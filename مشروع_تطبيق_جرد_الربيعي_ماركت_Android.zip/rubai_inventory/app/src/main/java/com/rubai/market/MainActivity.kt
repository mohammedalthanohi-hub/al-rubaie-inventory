package com.rubai.market

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class StockDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "rubai_stock.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE items(barcode TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT, qty REAL NOT NULL DEFAULT 0, counted REAL NOT NULL DEFAULT 0, cost REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, updated TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun save(barcode:String,name:String,category:String,qty:Double,counted:Double,cost:Double,price:Double) {
        val v=ContentValues().apply { put("barcode",barcode);put("name",name);put("category",category);put("qty",qty);put("counted",counted);put("cost",cost);put("price",price);put("updated",System.currentTimeMillis().toString()) }
        writableDatabase.insertWithOnConflict("items",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun get(barcode:String): android.database.Cursor = readableDatabase.rawQuery("SELECT name,category,qty,counted,cost,price FROM items WHERE barcode=?", arrayOf(barcode))
    fun summary(): String {
        val c=readableDatabase.rawQuery("SELECT COUNT(*),SUM(CASE WHEN counted>qty THEN 1 ELSE 0 END),SUM(CASE WHEN counted<qty THEN 1 ELSE 0 END),SUM((counted-qty)*cost) FROM items",null)
        c.moveToFirst(); val s="الأصناف: ${c.getInt(0)}\nأصناف زائدة: ${c.getInt(1)}\nأصناف ناقصة: ${c.getInt(2)}\nقيمة فرق التكلفة: ${"%.2f".format(c.getDouble(3))}"; c.close(); return s
    }
    fun csv(): String {
        val c=readableDatabase.rawQuery("SELECT barcode,name,category,qty,counted,cost,price,(counted-qty) FROM items ORDER BY name",null)
        val b=StringBuilder("الباركود,اسم الصنف,المجموعة,رصيد النظام,الكمية المجردة,سعر الشراء,سعر البيع,الفرق\n")
        while(c.moveToNext()) { for(i in 0 until 8) { if(i>0)b.append(','); b.append('"').append(c.getString(i)?.replace("\"","\"\"") ?: "").append('"') }; b.append('\n') }; c.close(); return b.toString()
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var db: StockDb
    private lateinit var preview: PreviewView
    private lateinit var barcode: EditText
    private lateinit var name: EditText
    private lateinit var category: EditText
    private lateinit var systemQty: EditText
    private lateinit var countedQty: EditText
    private lateinit var cost: EditText
    private lateinit var price: EditText
    private lateinit var status: TextView
    private var busy=false
    private val executor=Executors.newSingleThreadExecutor()
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if(ok) startCamera() else status.text="إذن الكاميرا مرفوض. فعّله من إعدادات التطبيق." }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=StockDb(this); buildUi() }
    private fun buildUi() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18); layoutDirection=android.view.View.LAYOUT_DIRECTION_RTL }
        fun field(hint:String): EditText = EditText(this).apply { this.hint=hint; textSize=16f; singleLine=true }
        root.addView(TextView(this).apply { text="جرد الربيعي ماركت"; textSize=24f; gravity=Gravity.CENTER; setPadding(0,8,0,12) })
        preview=PreviewView(this).apply { layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f); scaleType=PreviewView.ScaleType.FILL_CENTER }
        root.addView(preview)
        status=TextView(this).apply { text="وجّه الكاميرا نحو الباركود"; textSize=14f; setPadding(4,8,4,8) }; root.addView(status)
        barcode=field("الباركود"); root.addView(barcode)
        name=field("اسم الصنف"); root.addView(name)
        category=field("المجموعة"); root.addView(category)
        systemQty=field("رصيد النظام (اختياري)"); systemQty.inputType=2; root.addView(systemQty)
        countedQty=field("الكمية الفعلية"); countedQty.inputType=8194; root.addView(countedQty)
        cost=field("سعر الشراء"); cost.inputType=8194; root.addView(cost)
        price=field("سعر البيع"); price.inputType=8194; root.addView(price)
        val save=Button(this).apply { text="حفظ الصنف / تحديث الجرد"; setOnClickListener { saveItem() } }; root.addView(save)
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text="تقرير الجرد"; setOnClickListener { status.text=db.summary() } }, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        row.addView(Button(this).apply { text="تصدير CSV"; setOnClickListener { shareCsv() } }, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        root.addView(row)
        setContentView(root)
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera() else permission.launch(Manifest.permission.CAMERA)
    }
    private fun startCamera() {
        val future=ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider=future.get(); val p=Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val scanner=BarcodeScanning.getClient()
                val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media=proxy.image
                    if(media==null || busy) { proxy.close(); return@setAnalyzer }
                    busy=true
                    val image=InputImage.fromMediaImage(media,proxy.imageInfo.rotationDegrees)
                    scanner.process(image).addOnSuccessListener { codes ->
                        val value=codes.firstOrNull()?.rawValue
                        if(!value.isNullOrBlank() && barcode.text.toString()!=value) runOnUiThread { barcode.setText(value); loadItem(value); status.text="تمت قراءة الباركود: $value" }
                    }.addOnCompleteListener { busy=false; proxy.close() }
                }
                provider.unbindAll(); provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis)
            } catch(e:Exception) { status.text="تعذر تشغيل الكاميرا: ${e.localizedMessage}" }
        },ContextCompat.getMainExecutor(this))
    }
    private fun loadItem(code:String) {
        val c=db.get(code); if(c.moveToFirst()) { name.setText(c.getString(0));category.setText(c.getString(1));systemQty.setText(c.getString(2));countedQty.setText(c.getString(3));cost.setText(c.getString(4));price.setText(c.getString(5)) }; c.close()
    }
    private fun n(e:EditText)=e.text.toString().toDoubleOrNull() ?: 0.0
    private fun saveItem() {
        val code=barcode.text.toString().trim(); val nm=name.text.toString().trim()
        if(code.isEmpty() || nm.isEmpty()) { status.text="أدخل الباركود واسم الصنف"; return }
        db.save(code,nm,category.text.toString(),n(systemQty),n(countedQty),n(cost),n(price)); status.text="تم حفظ $nm محليًا على الجهاز"
        barcode.text.clear(); name.text.clear();category.text.clear();systemQty.text.clear();countedQty.text.clear();cost.text.clear();price.text.clear()
    }
    private fun shareCsv() {
        val file=java.io.File(cacheDir,"jard_alrubai_market.csv"); file.writeText("\uFEFF"+db.csv(),Charsets.UTF_8)
        val uri=androidx.core.content.FileProvider.getUriForFile(this,packageName+".provider",file)
        val intent=android.content.Intent(android.content.Intent.ACTION_SEND).apply { type="text/csv"; putExtra(android.content.Intent.EXTRA_STREAM,uri); addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(android.content.Intent.createChooser(intent,"تصدير بيانات الجرد"))
    }
}
